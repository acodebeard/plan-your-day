<?php
declare( strict_types=1 );

namespace Acodebeard\PlanYourDay\Frontend;

defined( 'ABSPATH' ) || exit;

final class PlannerShortcode {
	public const TAG = 'plan_your_day';

	private FrontendAssets $assets;
	private PlannerRenderer $renderer;

	public function __construct( PlannerRenderer $renderer, FrontendAssets $assets ) {
		$this->renderer = $renderer;
		$this->assets   = $assets;
	}

	public function register(): void {
		add_shortcode( self::TAG, [ $this, 'render' ] );
	}

	public function render( array|string $attributes = [], ?string $content = null, string $tag = self::TAG ): string {
		$attributes = shortcode_atts(
			[
				'action_url' => '',
			],
			is_array( $attributes ) ? $attributes : [],
			$tag
		);

		$action_url = esc_url_raw( (string) $attributes['action_url'] );

		/*
		 * Some themes still enqueue an older planner controller that binds to the
		 * same data attributes as this shortcode. Dequeue that legacy footer
		 * script here so the plugin remains the single source of interactive
		 * behavior for the rendered planner instance.
		 */
		if ( wp_script_is( 'dkc-plan', 'enqueued' ) ) {
			wp_dequeue_script( 'dkc-plan' );
		}

		$this->assets->enqueue();

		return $this->renderer->render( $_GET, $action_url );
	}
}
